# v0.1.3.1
- Patched latitude/longitude formatting for increased flexibility with expected use cases
- Updated README

# v0.1.3
- Added pristinesra() functionality
